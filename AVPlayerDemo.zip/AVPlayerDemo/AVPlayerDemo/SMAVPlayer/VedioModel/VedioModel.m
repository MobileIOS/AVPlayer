//
//  VedioModel.m
//  AVPlayerDemo
//
//  Created by Yx on 15/12/1.
//  Copyright © 2015年 WuhanBttenMobileTechnologyCo.,Ltd. All rights reserved.
//

#import "VedioModel.h"

@implementation VedioModel


@end
