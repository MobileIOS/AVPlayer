//
//  UserVideo.m
//  AVPlayerDemo
//
//  Created by Yx on 15/12/3.
//  Copyright © 2015年 WuhanBttenMobileTechnologyCo.,Ltd. All rights reserved.
//

#import "UserVideo.h"

@implementation UserVideo
@synthesize title;
@synthesize createTime;
@synthesize userid;
@synthesize videoType;
@synthesize playTime;
@synthesize videoUrl;
@synthesize picUrl;
@end
