//
//  PlayerHistoryViewController.h
//  AVPlayerDemo
//
//  Created by Yx on 15/12/2.
//  Copyright © 2015年 WuhanBttenMobileTechnologyCo.,Ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PlayerHistoryViewController : UIViewController

@end
