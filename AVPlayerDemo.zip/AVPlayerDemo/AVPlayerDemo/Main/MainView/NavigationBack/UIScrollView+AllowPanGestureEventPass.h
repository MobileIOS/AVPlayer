//
//  UIScrollView+AllowPanGestureEventPass.h
//  CoExistOfScrollViewAndBackGesture
//
//  Created by 乐星宇 on 14-5-1.
//  Copyright (c) 2014年 Lxy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIScrollView (AllowPanGestureEventPass)
@end
