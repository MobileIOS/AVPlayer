//
//  NSDate+SMDate.h
//  AVPlayerDemo
//
//  Created by Yx on 15/9/8.
//  Copyright © 2015年 WuhanBttenMobileTechnologyCo.,Ltd. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDate (SMDate)

- (int)year;
- (int)month;
- (int)day;
- (int)hour;
- (int)minute;

@end
